Before playing the game, please setup the environment variable first.

1.open Computer > System Properties >Advanced system settings > Advanced > Enviroment Variables > System Variables > New

2.create a new System variable
	Variable name: EXE4J_JAVA_HOME
	Variable value: (game folder path)\Java

3. press OK and restart your computer